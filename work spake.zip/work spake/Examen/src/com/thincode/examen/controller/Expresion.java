package com.thincode.examen.controller;

import com.thincode.examen.modelo.Registro;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.*;

public class Expresion {
	
	public Registro recuperaDatos(String resitro) throws ParseException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyyy");
		Date fecha = new Date();
		Registro resul =new Registro();
	    Pattern p = Pattern.compile("(\\d) ([a-zA-Z ]+) (\\d\\d) (\\d{2}\\/\\d{2}\\/\\d{4}) ([a-zA-Z0-9\\.^ |^\\n|^@]+@[a-zA-Z0-9^ |^\\n|^@]+\\.[a-zA-Z]{3})");
	    Matcher m = p.matcher(resitro);
	    
	    if (m.find()) {
		    resul.setId(Integer.valueOf(m.group(1).toString()));
		    resul.setNombre(m.group(2).toString());
		    resul.setEdad(Integer.valueOf(m.group(3).toString()));
		    fecha=sdf.parse(m.group(4).toString());
		    resul.setFechaNacimiento(fecha);
		    resul.setCorreo(m.group(5).toString());
	    }else {
	    	
	    	System.out.println("Expresion no regreso coincidencias con la cadena["+resitro+"]");
	    }
	     return resul;
	}
	
	

}
