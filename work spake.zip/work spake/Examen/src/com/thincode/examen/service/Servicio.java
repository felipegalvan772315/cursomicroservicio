package com.thincode.examen.service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.swing.text.StyledEditorKit.BoldAction;

import com.thincode.examen.controller.Archivo;
import com.thincode.examen.controller.Expresion;
import com.thincode.examen.modelo.Registro;

public class Servicio {
	Archivo archivo = new Archivo();
	
	public void cargaArchivo() {
	   if (archivo.cargaArchivo()) {
		   System.out.println("Carga de datos correcta");
	   }else {
		   System.err.println("Error al cargar datos de archivo");   
	   }
	}
	
	public void consultarDatos() {
		
		System.out.println("Mostrando todos los registros");
		 
		for(Registro reg :archivo.muestraLista()) {
			System.out.println(reg.toString());
		}
	}
	
	public void consultarDatosId(int id) {
		Registro reg = new Registro();
		
		System.out.println("Consulta registro:["+id+"]");
		reg = archivo.muestraListaId(id) ;
		
		if(reg!=null) {
			System.out.println(reg.toString());
		}else {
			System.err.println("Registro no encontrado");
		}
	}
	

}
