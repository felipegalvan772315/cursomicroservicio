package com.thincode.ejmplo2.demorest01.service;

import java.lang.reflect.Array;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.thincode.ejmplo2.demorest01.beans.Usuario;


@Service
public class Servicio {

	
	ArrayList<Usuario> listaUsuarios= new ArrayList<Usuario>();
	
	
	public int altaUsuario(Usuario usuario) {
		
		listaUsuarios.add(usuario);
		
		return 1;
	}
	
	public ArrayList<Usuario> consulataAll() {
		
		return listaUsuarios;
	}
	
	public Usuario consulataUsuario(String id) {
		
		Usuario Consulta = new Usuario();
		
		listaUsuarios.forEach(usua->{
			if(id.equals(usua.getUsuario())){
				Consulta.setUsuario(usua.getUsuario()) ;
				Consulta.setNombre(usua.getNombre()) ;
				Consulta.setPassword(usua.getPassword()) ;
				Consulta.setEdad(usua.getEdad()) ;
				Consulta.setCorreo(usua.getCorreo()) ;
			}
		});
		
		return Consulta;
	}
	
	public Usuario modificarUsuario(Usuario usuario) {
		
		listaUsuarios.forEach(usua->{
			if(usuario.getUsuario().equals(usua.getUsuario())){
				listaUsuarios.set(listaUsuarios.indexOf(usua), usuario);
			}
		});
	
		return usuario;
	}
	
	public boolean borrarUsuario(String id) {
		
		boolean bandera = false;
		
		for( Usuario usua : listaUsuarios ){
			if(id.equals(usua.getUsuario())){
				listaUsuarios.remove(usua);
				bandera =true;
				break;
			}
		};
		
		return bandera;
	}
}


