package com.thincode.examen.modelo;

import java.text.SimpleDateFormat;
import java.util.Date;


public class Registro {
	
	private Integer id;
	private String nombre;
	private Integer edad;
	private Date fechaNacimiento;
	private String correo ;
	
	public Registro() {
	
	}
	
	public Registro(Integer id, String nombre,Integer edad, Date fechaNacimiento,String correo) {
		this.id=id;
		this.nombre=nombre;
		this.edad=edad;
		this.fechaNacimiento=fechaNacimiento;
		this.correo = correo ;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getEdad() {
		return edad;
	}
	public void setEdad(Integer edad) {
		this.edad = edad;
	}
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public String toString() {
		return "id:["+id+"] Nombre:["+nombre+"] Edad:["+edad+"] Fecha de nacimiento: ["+new SimpleDateFormat("dd-MM-yyyy").format(fechaNacimiento)+"] Correo:["+correo+"]";
	}

}
