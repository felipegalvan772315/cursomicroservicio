package com.thincode.curso.usuarios.controller.beans;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {
	
	private String numeroDeCliente;
	private String nombreDeCliente;
	private ArrayList<TarjetaCredito> tarjetas;
	
}
