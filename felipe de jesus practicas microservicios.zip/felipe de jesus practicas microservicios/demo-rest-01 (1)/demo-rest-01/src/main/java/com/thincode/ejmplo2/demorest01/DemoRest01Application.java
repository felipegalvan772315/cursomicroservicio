package com.thincode.ejmplo2.demorest01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRest01Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoRest01Application.class, args);
	}

}
