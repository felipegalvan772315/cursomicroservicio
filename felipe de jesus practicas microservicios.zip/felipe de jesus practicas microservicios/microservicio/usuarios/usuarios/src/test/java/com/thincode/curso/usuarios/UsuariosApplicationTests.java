package com.thincode.curso.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
