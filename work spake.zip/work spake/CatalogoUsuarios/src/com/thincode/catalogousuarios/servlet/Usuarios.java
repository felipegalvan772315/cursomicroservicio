package com.thincode.catalogousuarios.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.DriverConnectionFactory;


import com.mysql.jdbc.Driver;
import com.thincode.catalogousuario.controller.usuario;


public class Usuarios extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("Llamando a metodo usuario... GET");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
       System.out.println("Llamando a metodo usuario... pos");	
	   
	   usuario objUsuario =new usuario(req.getParameter("usuario"),req.getParameter("nombre"),req.getParameter("correo"),req.getParameter("edad"),req.getParameter("fecha"),Integer.valueOf(req.getParameter("contador")));
	   
	   Hilo alta =new Hilo(objUsuario);
	   
	   alta.start(); 
	}

}
