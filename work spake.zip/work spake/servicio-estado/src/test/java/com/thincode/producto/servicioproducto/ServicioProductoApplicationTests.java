package com.thincode.producto.servicioproducto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioProductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
