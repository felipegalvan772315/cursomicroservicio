package com.thincode.practica.services;

import java.util.ArrayList;

import com.thincode.practica.controller.Persona;
import com.thincode.practica.implementacion.Mysql;
import com.thincode.practica.implementacion.Oracle;

public class Services {
	
	Mysql bdMySql =new Mysql();
	Oracle bdOracle = new Oracle();
	
	public String activeBd= new String();
	
	public void altaPersona(int id,String nombre,String calle,int edad,String telefono) {
		Persona persn = new Persona();
		int flagcorrecto = 0;
		
		persn.setId(id);
		persn.setNombre(nombre);
		persn.setCalle(calle);
		persn.setEdad(edad);
		persn.setTelefono(telefono);
		
		if(activeBd.equals("MySql")){
			
			flagcorrecto= bdMySql.altaPersona(persn);
		}else {
			
			flagcorrecto = bdOracle.altaPersona(persn);
		
		}	
		
		if ( flagcorrecto == 1 ) {
			System.out.println("Alta correcta de Persona " + persn.getNombre().toString() );
		}else {
			System.out.println("Fallo alta de Persona "+ persn.getNombre().toString());
		}
	}
	
	public void modPersona(int id,String nombre,String calle,int edad,String telefono) {
		Persona persn = new Persona();
		int flagcorrecto = 0;
		persn.setId(id);
		persn.setNombre(nombre);
		persn.setCalle(calle);
		persn.setEdad(edad);
		persn.setTelefono(telefono);
		
		if( activeBd.equals("MySql") ){
			flagcorrecto = bdMySql.modificacionPersona(persn);
		}else {
			flagcorrecto = bdOracle.modificacionPersona(persn);
		}	
		
		if ( flagcorrecto == 1 ) {
			System.out.println("Modificacion correcta de persona " + persn.getNombre().toString() );
		}else {
			System.out.println("Fallo modificacion de Persona "+ persn.getNombre().toString());
		}
	}
	
	public void borrPersona(int id) {
		int flagcorrecto = 0;
		
		if(activeBd.equals("MySql")){
			flagcorrecto = bdMySql.bajaPersona(id);
		}else {
			flagcorrecto = bdOracle.bajaPersona(id);
		}	
		
		if ( flagcorrecto == 1 ) {
			System.out.println("Borrado correcto de persona " + id );
		}else {
			System.out.println("Fallo borrado de Persona "+ id );
		}
	}
	
	
	public void consPersona(int id) {
		
		Persona persn = new Persona();
		
		persn=null;
		
		if(activeBd.equals("MySql")){
			
			persn = bdMySql.consultarPersonaId(id);
			
		}else {
			persn = bdOracle.consultarPersonaId(id);
			
		}	
		
		if (persn==null) {
			System.out.println("Persona "+ id +" no encontrada" );
		}else {
			
			System.out.println(persn.print());
		}
			
		
	}
	
	
	public void consPersonas() {
		
		ArrayList<Persona> list = new ArrayList<Persona>();
		
		if(activeBd.equals("MySql")){
			list = bdMySql.consultarAll();
		}else {
			list = bdOracle.consultarAll();
		}	
		 System.out.println("Imprimiendo lista");
		for(Persona per :list) {
			
			System.out.println(per.print());
		}
	}
	
	

}
