package com.thincode.ejmplo2.demorest01;

import java.awt.List;
import java.util.ArrayList;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.ejmplo2.demorest01.beans.Usuario;
import com.thincode.ejmplo2.demorest01.service.Servicio;

@RestController
public class Controler {
	
	@Autowired
    private  Servicio servicio;
		
	@GetMapping("/version")
	public String version() {
		 
		return "Rest version 1.0";
		
	}
	
	@PostMapping("/altausuario")
	public Usuario usuarioPost(@RequestBody Usuario usuario) {
		servicio.altaUsuario(usuario);
		return usuario;
	}
	
	@GetMapping("/consultatodos")
	public ArrayList<Usuario> usuario() {
		return servicio.consulataAll();
	}
	
	@PostMapping("/consultausuario/{id}")
	public Usuario usuario(@PathVariable String id) {
		 
		return servicio.consulataUsuario(id);
		 
	}
	
	@PutMapping("/modificacionusuario")
	public Usuario modificacionusuarioPost(@RequestBody Usuario usuario) {

		return  servicio.modificarUsuario(usuario);
	}
	
	@DeleteMapping("/bajausuario/{id}")
	public String bajausuarioDelete(@PathVariable  String id) {
       String resul=new String();
        
       if (servicio.borrarUsuario(id)){
    	   
    	   resul="Usuario borrado correctamente";
       }else {
    	   resul="Error al borrar el Usuario";
    	   
       }
       
		return resul;
   	}
	
}
